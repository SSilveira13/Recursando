#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "colores.h"

/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int parser_ComponentesFromText(FILE* pFile , LinkedList* this)
{
    int retorno = -1;
    Componentes *aux;
    char var1[50],var2[50],var3[50];
    if(pFile == NULL)
    {
        retorno = -1;
        //printf("Llega..."); system("pause");
    }
    else
    {
        fscanf(pFile,"%[^;];%[^;];%[^\n]\n",var1,var2,var3);
        do
        {
            retorno = fscanf(pFile,"%[^;];%[^;];%[^\n]\n",var1,var2,var3);
            //printf("%s %s %s %s", var1, var2, var3, var4);
            if(retorno==3)
            {
                aux = componente_nuevo();
                if(componentes_parametros(aux,var1,var2,var3)==0)
                {
                    ll_add(this,aux);
                    retorno = 0;
                }
            }
        }while(!feof(pFile));
    }
    fclose(pFile);
    return retorno;
}


int parser_ColoresFromText(FILE* pFile , LinkedList* this)
{
    int retorno = -1;
    Colores* aux;
    char var1[50],var2[50],var3[50],var4[50];
    if(pFile == NULL)
    {
        retorno = -1;
        //printf("Llega..."); system("pause");
    }
    else
    {
        fscanf(pFile,"%[^;];%[^;];%[^;];%[^\n]\n",var1,var2,var3,var4);
        do
        {
            retorno = fscanf(pFile,"%[^;];%[^;];%[^;];%[^\n]\n",var1,var2,var3,var4);
            //printf("%s %s %s %s", var1, var2, var3, var4);
            if(retorno==4)
            {
                aux = color_nuevo();
                if(color_parametros(aux,var1,var2,var3,var4)==0)
                {
                    ll_add(this,aux);
                    retorno = 0;
                }
            }
        }while(!feof(pFile));
    }
    fclose(pFile);
    return retorno;
}
