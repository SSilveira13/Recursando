int parser_ComponentesFromText(FILE* pFile , LinkedList* this);
int parser_ColoresFromText(FILE* pFile , LinkedList* this);
