#ifndef COLORES_H_INCLUDED
#define COLORES_H_INCLUDED

typedef struct{
int id_componente;
char nombre[31];
int es_base;
}Componentes;

typedef struct{
int id_color;
char nombre[31];
int id_componente;
int cantidad;
}Colores;

void main_menu();
Componentes* componente_nuevo();
Colores* color_nuevo();

int componentes_parametros(Componentes* aux,char *var1,char *var2,char *var3);
int color_parametros(Colores *aux,char *var1,char *var2,char *var3,char *var4);

int alta_de_ingrediente(LinkedList *this);
void mod_de_ingrediente(LinkedList *this);
void baja_ingrediente(LinkedList* this);
int orden_ingredientes(void *elementoA,void *elementoB);
//void informar_color(LinkedList *this);
void nuevo_color(LinkedList *color,LinkedList *componentes);
void listar_ingredientes(LinkedList* this);

int componente_setId(Componentes* this,int id_componente);
int componente_getId(Componentes* this,int* id_componente);
int componente_setNombre(Componentes* this,char* nombre);
int componente_getNombre(Componentes* this,char* nombre);
int componente_setEsBase(Componentes* this,int es_base);
int componente_getEsBase(Componentes* this,int* es_base);

int colores_setId(Colores* this,int id_color);
int colores_getId(Colores* this,int* id_color);
int colores_setNombre(Colores* this,char* nombre);
int colores_getNombre(Colores* this,char* nombre);
int colores_setIdComponente(Colores* this,int id_componente);
int colores_getIdComponente(Colores* this,int* id_componente);
int colores_setCantidad(Colores* this,int cantidad);
int colores_getCantidad(Colores* this,int* cantidad);


#endif
