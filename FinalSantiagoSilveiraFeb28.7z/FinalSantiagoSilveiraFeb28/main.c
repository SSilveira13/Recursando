#include <stdio.h>
#include <stdlib.h>
#include "utn.h"
#include "LinkedList.h"
#include "parser.h"
#include "colores.h"

int main()
{
    LinkedList* this_componentes;
    this_componentes = ll_newLinkedList();
    LinkedList* this_colores;
    this_colores = ll_newLinkedList();
    FILE* archivo_componentes;
    FILE* archivo_colores;
    archivo_componentes = fopen("componente_base.csv","r");
    archivo_colores = fopen("color.csv","r");
    if(parser_ComponentesFromText(archivo_componentes,this_componentes)==0)
    {
        printf("Se cargo el archivo: componente_base.csv\n");
    }
    if(parser_ColoresFromText(archivo_colores,this_colores)==0)
    {
        printf("Se cargo el archivo: color.csv\n");
    }
    system("pause");
    int option = 0;
    do{
        system("cls");
        main_menu();
        utn_getEntero(&option,"","Error en el menu",1,7,1);
        switch(option)
        {
            case 1://ALTA
                system("cls");
                alta_de_ingrediente(this_componentes);
                break;
            case 2://MOD
                system("cls");
                mod_de_ingrediente(this_componentes);
                break;
            case 3://BAJA
                system("cls");
                baja_ingrediente(this_componentes);
                break;
            case 4://LISTAR
                system("cls");
                listar_ingredientes(this_componentes);
                system("pause");
                break;
            case 5://COLOR
                system("cls");
                nuevo_color(this_colores,this_componentes);
                break;
            case 6://INFORMAR COMPONENTES
                system("cls");

                break;
            case 7://SALIR
                break;
        }
    }while(option!=7);
    return 0;
}
