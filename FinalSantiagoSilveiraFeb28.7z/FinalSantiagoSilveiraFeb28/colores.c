#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utn.h"
#include "LinkedList.h"
#include "parser.h"
#include "colores.h"

void main_menu()
{
    printf("MENU\n\n1_Alta de ingrediente.\n2_Modificar ingrediente.\n3_Baja de ingrediente.\n4_listar componentes.\n5_Nuevo color.\n6_Informar componentes del color.\n7_Salir.");
}

Componentes* componente_nuevo()
{
    Componentes *aux, *retorno=NULL;
    aux = (Componentes*)malloc(sizeof(Componentes));
    if(aux!=NULL)
    {
        retorno = aux;
    }
    return retorno;
}

Colores* color_nuevo()
{
    Colores *aux, *retorno=NULL;
    aux = (Colores*)malloc(sizeof(Colores));
    if(aux!=NULL)
    {
        retorno = aux;
    }
    return retorno;
}

int componentes_parametros(Componentes* aux,char *var1,char *var2,char *var3)
{
    int id,es_base,retorno = -1;
    if(aux!=NULL)
    {
        retorno = 0;
        id = atoi(var1);
        es_base = atoi(var3);
        componente_setId(aux,id);
        componente_setNombre(aux,var2);
        componente_setEsBase(aux,es_base);
    }
    return retorno;
}
int color_parametros(Colores *aux,char *var1,char *var2,char *var3,char *var4)
{
    int id_color,id_componente,cantidad,retorno = -1;
    if(aux!=NULL)
    {
        retorno = 0;
        id_color = atoi(var1);
        id_componente = atoi(var3);
        cantidad = atoi(var4);
        colores_setId(aux,id_color);
        colores_setNombre(aux,var2);
        colores_setIdComponente(aux,id_componente);
        colores_setCantidad(aux,cantidad);
    }
    return retorno;
}

int alta_de_ingrediente(LinkedList *this)
{
    int es_base,retorno=-1;
    char nombre[31];
    if(this!=NULL)
    {
        Componentes *aux;
        aux = componente_nuevo();
        if(aux!=NULL)
        {
            utn_getCadena(nombre,"Ingrese el nombre del componente: ","Error",1);
            utn_getEntero(&es_base,"Es base(1) o pigmento(0): ","Error",0,1,1);
            aux->id_componente = ll_len(this) + 1;
            strcpy(aux->nombre,nombre);
            aux->es_base = es_base;
            if(ll_add(this,aux)==0)
            {
                retorno = 0;
            }
        }
    }
    return retorno;
}

void mod_de_ingrediente(LinkedList *this)
{
    int option,id_componente,intAux;
    char stringAux[31];
    void *aux;
    utn_getEntero(&id_componente,"Ingrese ID del componente a modificar: ","Error",0,99999,1);
    aux = ll_get(this,id_componente);
    utn_getEntero(&option,"MENU MOD\n1_Nombre\n2_Es base\n3_Salir\n\n","Error",1,3,1);
    switch(option)
    {
        case 1:
            utn_getCadena(stringAux,"Nuevo nombre: ","Error",1);
            componente_setNombre(aux,stringAux);
            break;
        case 2:
            utn_getEntero(&intAux,"Es base(1) o pigmento(0): ","Error",0,1,1);
            componente_setEsBase(aux,intAux);
            break;
        case 3:
            break;
    }
}

void baja_ingrediente(LinkedList* this)
{
    int id;
    utn_getEntero(&id,"Ingresar ID del componente: ","Error",0,ll_len(this),2);
    ll_remove(this,id);
}

void listar_ingredientes(LinkedList* this)
{
    int index;
    Componentes* aux;
    //void *auxA,*auxB;
    //ll_sort(this,orden_ingredientes(),1);
    for(index=0;index<ll_len(this);index++)
    {
         aux=(Componentes*)ll_get(this,index);
         printf("ID: %d\tNombre: %s\tEs base: %d\n\n",aux->id_componente,aux->nombre,aux->es_base);
    }
}


int orden_ingredientes(void *elementoA,void *elementoB)
{
    int retorno = 0;
    if(strcmp((char*)elementoA,(char*)elementoB)>0)
    {
        retorno = 1;
    }
    if(strcmp((char*)elementoA,(char*)elementoB)<0)
    {
        retorno = -1;
    }
    return retorno;
}



void nuevo_color(LinkedList *color,LinkedList *componentes)
{
    int index,flag=0,id_componente,cantidad;
    char nombre[31];
    Colores *aux,*comparar;
    Componentes *checkBase;
    if(color!=NULL && componentes!=NULL)
    {
        aux = color_nuevo();
        if(aux!=NULL)
        {
            utn_getCadena(nombre,"Ingrese el nombre del color: ","Error",1);
            utn_getEntero(&id_componente,"Ingrese la ID del componente: ","Error",0,99999,1);
            for(index=0;index<ll_len(color);index++)
            {
                comparar = (Colores*)ll_get(color,index);
                if(strcmp(nombre,comparar->nombre)==0 && comparar!=NULL)
                {
                    checkBase = ll_get(componentes,comparar->id_componente);
                    if(checkBase!=NULL && checkBase->es_base==1)
                    {
                        flag = 1;
                    }
                }
            }
            utn_getEntero(&cantidad,"Ingrese cantidad de componente: ","Error",0,999999,1);
            if(flag==0)
            {
                printf("No se puede ingresar otra base cuando ya se tiene una.");
                system("pause");
            }
            else
            {
                colores_setId(aux,ll_len(color) + 1);
                colores_setNombre(aux,nombre);
                colores_setIdComponente(aux,id_componente);
                colores_setCantidad(aux,cantidad);
                ll_add(color,aux);
            }
        }
    }
}

/*void informar_color(LinkedList *this)
{
    int id,litros;
    utn_getEntero(&id,"Ingrese ID del color: ","Error",0,99999,1);
    utn_getEntero(&litros,"Ingrese cantidad de litros: ","Error",0,99999,1);
}*/














int componente_setId(Componentes* this,int id_componente)
{
    int retorno = -1;
    if(id_componente >= 0 && this!=NULL)
    {
        this->id_componente = id_componente;
        retorno = 0;
    }
    return retorno;
}
int componente_getId(Componentes* this,int* id_componente)
{
    int retorno = -1;
    if(this!=NULL)
    {
        retorno = 0;
        *id_componente = this->id_componente;
    }
    return retorno;
}

int componente_setNombre(Componentes* this,char* nombre)
{
    int retorno = -1;
    if(nombre != NULL && this != NULL)
    {
        strcpy(this->nombre,nombre);
        retorno = 0;
    }
    return retorno;
}
int componente_getNombre(Componentes* this,char* nombre)
{
    int retorno = -1;
    if(this!=NULL)
    {
        retorno = 0;
        strcpy(nombre,this->nombre);
    }
    return retorno;
}

int componente_setEsBase(Componentes* this,int es_base)
{
    int retorno = -1;
    if(es_base >= 0 && this!=NULL)
    {
        this->es_base = es_base;
        retorno = 0;
    }
    return retorno;
}
int componente_getEsBase(Componentes* this,int* es_base)
{
    int retorno = -1;
    if(this!=NULL)
    {
        retorno = 0;
        *es_base = this->es_base;
    }
    return retorno;
}


int colores_setId(Colores* this,int id_color)
{
    int retorno = -1;
    if(id_color >= 0 && this!=NULL)
    {
        this->id_color = id_color;
        retorno = 0;
    }
    return retorno;
}
int colores_getId(Colores* this,int* id_color)
{
    int retorno = -1;
    if(this!=NULL)
    {
        retorno = 0;
        *id_color = this->id_color;
    }
    return retorno;
}

int colores_setNombre(Colores* this,char* nombre)
{
    int retorno = -1;
    if(nombre != NULL && this != NULL)
    {
        strcpy(this->nombre,nombre);
        retorno = 0;
    }
    return retorno;
}
int colores_getNombre(Colores* this,char* nombre)
{
    int retorno = -1;
    if(this!=NULL)
    {
        retorno = 0;
        strcpy(nombre,this->nombre);
    }
    return retorno;
}

int colores_setIdComponente(Colores* this,int id_componente)
{
    int retorno = -1;
    if(id_componente >= 0 && this!=NULL)
    {
        this->id_componente = id_componente;
        retorno = 0;
    }
    return retorno;
}
int colores_getIdComponente(Colores* this,int* id_componente)
{
    int retorno = -1;
    if(this!=NULL)
    {
        retorno = 0;
        *id_componente = this->id_componente;
    }
    return retorno;
}

int colores_setCantidad(Colores* this,int cantidad)
{
    int retorno = -1;
    if(cantidad >= 0 && this!=NULL)
    {
        this->cantidad = cantidad;
        retorno = 0;
    }
    return retorno;
}
int colores_getCantidad(Colores* this,int* cantidad)
{
    int retorno = -1;
    if(this!=NULL)
    {
        retorno = 0;
        *cantidad = this->cantidad;
    }
    return retorno;
}
