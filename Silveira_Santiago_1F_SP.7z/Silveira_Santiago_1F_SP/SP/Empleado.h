#ifndef EMPLEADO_H_INCLUDED
#define EMPLEADO_H_INCLUDED

#include "LinkedList.h"

struct S_Empleado
{
  int id;
  char nombre[128];
  int horasTrabajadas;
  int sueldo;
};
typedef struct S_Empleado Empleado;

void em_calcularSueldo(void* p);

void al_map(LinkedList* this, void (*pFunc)(void* p));

Empleado* employee_new();

Empleado* employee_newParametros(Empleado* this,char* var1,char* var2,char* var3);

int employee_setId(Empleado* this,int id);

int employee_setNombre(Empleado* this,char* nombre);

int employee_setHorasTrabajadas(Empleado* this,int horasTrabajadas);

int employee_setSueldo(Empleado* this,int sueldo);

int employee_getId(LinkedList* this,int index);

int employee_getHoras(LinkedList* this,int index);

int employee_getSueldo(LinkedList* this,int index);

char* employee_getNombre(LinkedList* this,int index);

void listar(LinkedList* this);

#endif // EMPLEADO_H_INCLUDED
