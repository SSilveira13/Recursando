#include <stdio.h>
#include <stdlib.h>
#include "Empleado.h"
#include "LinkedList.h"
#include "Parser.h"

int generarArchivoSueldos(char* binaryFile,char* textFile,LinkedList* listaEmpleados);

int main()
{
    // Definir lista de empleados
    LinkedList* listaEmpleados;

    // Crear lista empledos
    //...
    listaEmpleados = ll_newLinkedList();
    // Leer empleados de archivo data.csv
    if(parser_parseEmpleados("data.csv",listaEmpleados)==1)
    {
        //listar(listaEmpleados);
        // Calcular sueldos
        printf("Calculando sueldos de empleados\n");
        al_map(listaEmpleados,em_calcularSueldo);
        // Generar archivo de salida
        listar(listaEmpleados);
        if(generarArchivoSueldos("info.dat","info.csv",listaEmpleados)==1)
        {
            printf("Archivo generado correctamente\n");
        }
        else
        {
            printf("Error generando archivo\n");
        }
    }
    else
    {
        printf("Error leyendo empleados\n");
    }
    return 0;
}

int generarArchivoSueldos(char* binaryFile,char* textFile,LinkedList* this)
{
    int retorno = -1;
    int indice,sueldo,horas,identidicacion;
    char* nombre;
    Empleado aux;
    FILE* pFile;
    if(binaryFile!=NULL && textFile!=NULL && this!=NULL)
    {
        if ((pFile=fopen(binaryFile,"wb"))==NULL)
        {
            printf("El archivo no puede ser abierto");
            return -1;
        }
        for(indice=0;indice<=ll_len(this);indice++)
        {
            printf("\n%d",indice);
            identidicacion = employee_getId(this,indice);
            printf("\n3");
            horas = employee_getHoras(this,indice);
            sueldo = employee_getSueldo(this,indice);
            nombre = employee_getNombre(this,indice);
            printf("\n3");
            employee_setHorasTrabajadas(&aux,horas);
            employee_setId(&aux,identidicacion);
            employee_setSueldo(&aux,sueldo);
            employee_setNombre(&aux,nombre);
            printf("\n3");
            fwrite(&aux,sizeof(aux),1,pFile);
            printf("\n4");
        }
        fclose(pFile);
        if ((pFile=fopen(textFile,"w"))==NULL)
        {
            printf("El archivo no puede ser abierto");
            return -1;
        }
        for(indice=0;indice<=ll_len(this);indice++)
        {
            printf("\n3");
            identidicacion = employee_getId(this,indice);
            horas = employee_getHoras(this,indice);
            sueldo = employee_getSueldo(this,indice);
            nombre = employee_getNombre(this,indice);
            fscanf(pFile,"%d,%s,%d,%d\n",&identidicacion,nombre,&horas,&sueldo);
        }
        fclose(pFile);
        retorno = 1;
    }
    return retorno;
}
