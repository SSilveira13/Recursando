#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Empleado.h"

int parser_parseEmpleados(char* fileName, LinkedList* listaEmpleados)
{
    int retorno = -1;
    FILE* pFile;
    Empleado* aux;
    char var1[50],var3[50],var2[50];
    pFile = fopen(fileName,"r");
    if(pFile == NULL)
    {
        return -1;
    }
    retorno = fscanf(pFile,"%[^,],%[^,],%[^\n]\n",var1,var2,var3);
    do
    {
        retorno = fscanf(pFile,"%[^,],%[^,],%[^\n]\n",var1,var2,var3);
        //printf("%s %s %s", var1, var2, var3);
        if(retorno==3)
        {
            aux = employee_new();
            aux = employee_newParametros(aux,var1,var2,var3);
            ll_add(listaEmpleados, aux);
            retorno = 1;
        }
    }while(!feof(pFile));
    system("pause");
    fclose(pFile);
    return retorno;
}
