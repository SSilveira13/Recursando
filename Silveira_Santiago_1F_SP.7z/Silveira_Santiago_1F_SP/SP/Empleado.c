#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "Empleado.h"

void em_calcularSueldo(void* p)
{
    Empleado* aux;
    aux = (Empleado*)p;
    if(aux->horasTrabajadas <= 176)//$180
    {
        employee_setSueldo(aux,180);
    }
    else if(aux->horasTrabajadas >= 177 && aux->horasTrabajadas <= 208)//$270
    {
        employee_setSueldo(aux,270);
    }
    else if(aux->horasTrabajadas >= 209 && aux->horasTrabajadas <= 240)//$360
    {
        employee_setSueldo(aux,360);
    }
}

void al_map(LinkedList* this,void (*pFunc)(void* p))
{
    int indice;
    Empleado* aux;
    if(this!=NULL && pFunc!=NULL)
    {
        for(indice=0;indice<=ll_len(this);indice++)
        {
            //printf("\n%d",indice);
            aux = (Empleado*)ll_get(this,indice);
            if(aux!=NULL)
            {
                pFunc((void*)aux);
            }
        }
    }
}

Empleado* employee_new()
{
    Empleado* retorno = NULL,*aux = NULL;
    aux = (Empleado*) malloc(sizeof(Empleado));
    if(aux!=NULL)
    {
        retorno = aux;
    }
    return retorno;
}

Empleado* employee_newParametros(Empleado* this,char* var1,char* var2,char* var3)
{
    Empleado* retorno = NULL;
    int id,horas;
    char nombre[50];
    if(this!=NULL && var1!=NULL && var2!=NULL && var3!=NULL)
    {
        printf("%s",var1);
        id = atoi(var1);
        horas = atoi(var3);
        strcpy(nombre,var2);
        employee_setId(this,id);
        employee_setHorasTrabajadas(this,horas);
        employee_setNombre(this,nombre);
    }
    return retorno;
}

int employee_setId(Empleado* this,int id)
{
    int retorno = -1;
    if(id >= 0 && this!=NULL)
    {
        this->id = id;
        retorno = 0;
    }
    return retorno;
}

int employee_setNombre(Empleado* this,char* nombre)
{
    int retorno = -1;
    if(nombre != NULL && this != NULL)
    {
        strcpy(this->nombre,nombre);
        retorno = 0;
    }
    return retorno;
}

int employee_setHorasTrabajadas(Empleado* this,int horasTrabajadas)
{
    int retorno = -1;
    if(horasTrabajadas >= 0 && this!=NULL)
    {
        this->horasTrabajadas = horasTrabajadas;
        retorno = 0;
    }
    return retorno;
}

int employee_setSueldo(Empleado* this,int sueldo)
{
    int retorno = -1;
    if(sueldo >= 0 && this!=NULL)
    {
        this->sueldo = sueldo;
        retorno = 0;
    }
    return retorno;
}

int employee_getId(LinkedList* this,int index)
{
    int retorno = -1;
    Empleado* aux;

    if(this!=NULL)
    {
        aux = (Empleado*)ll_get(this,index);
        if(aux!=NULL)
        {
            //printf("%d", aux->id); system("pause");
            printf("1");
            retorno = aux->id;
            printf("2");
        }
    }
    else{
        printf("Es NULL..."); system("pause");
    }
    return retorno;
}

int employee_getHoras(LinkedList* this,int index)
{
    int retorno = -1;
    Empleado* aux;
    if(this!=NULL)
    {
        aux = (Empleado*)ll_get(this,index);
        retorno = aux->horasTrabajadas;
    }
    return retorno;
}

int employee_getSueldo(LinkedList* this,int index)
{
    int retorno = -1;
    Empleado* aux;
    if(this!=NULL)
    {
        aux = (Empleado*)ll_get(this,index);
        retorno = aux->sueldo;
    }
    return retorno;
}

char* employee_getNombre(LinkedList* this,int index)
{
    char* retorno = NULL;
    Empleado* aux;
    if(this!=NULL)
    {
        aux = (Empleado*)ll_get(this,index);
        retorno = aux->nombre;
    }
    return retorno;
}

void listar(LinkedList* this)
{
    int indice,id;
    if(this!=NULL)
    {
        for(indice=0;indice<=ll_len(this);indice++)
        {
            id = employee_getId(this,indice);
            printf("\nID:%d",id);
        }
    }
    system("pause");
}
