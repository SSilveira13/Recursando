int parser_SociosFromText(FILE* pFile , LinkedList* this);
int parser_FichajesFromText(FILE* pFile , LinkedList* this);
