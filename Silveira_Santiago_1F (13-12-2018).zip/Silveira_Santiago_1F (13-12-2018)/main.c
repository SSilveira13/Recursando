#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "parser.h"
#include "Envios.h"
#include "utn.h"

int main()
{
    LinkedList* this;
    this = ll_newLinkedList();
    FILE* archivo;
    char ficha[50];
    int option = 0;
    //int zona;
    //LinkedList* filtrado;
    if(this!=NULL)
    {

        do{
            system("cls");
            envio_menu();
            utn_getEntero(&option,"","Error en el menu",1,6,1);
            switch(option)
            {
                case 1://cargar archivo
                    utn_getCadena(ficha,"Ingrese el nombre del archivo(sin .csv): ","Error con el nombre del archivo.",1);
                    strcat(ficha,".csv");
                    archivo = fopen(ficha,"r");
                    if(parser_EnviosFromText(archivo,this)==0)
                    {
                        printf("Se cargo el archivo.\n");
                        system("pause");
                    }
                    break;
                case 2://imprimir envios
                    envio_listar(this);
                    break;
                case 3://calcular costos
                    ll_map(this);
                    break;
                case 4://generar archivo por zona
                    /*system("cls");
                    utn_getEntero(&zona,"","Error en la zona",1,20,1);
                    filtrado = ll_filter(this,zona);
                    if(filtrado!=NULL)
                    {

                        if(envio_guardarTextoPorNivel("info.csv",filtrado)==0)
                        {
                            printf("Se guardo el archivo\n");
                            system("pause");
                        }
                    }
                    break;*/
                case 5://listar zonas
                    system("cls");
                    listar_zonas(this);
                    system("pause");
                    break;
                case 6://salir
                    break;
            }
        }while(option!=6);
    }
    return 0;
}
