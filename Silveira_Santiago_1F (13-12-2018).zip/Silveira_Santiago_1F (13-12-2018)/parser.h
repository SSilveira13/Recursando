int parser_EnviosFromText(FILE* pFile , LinkedList* this);
