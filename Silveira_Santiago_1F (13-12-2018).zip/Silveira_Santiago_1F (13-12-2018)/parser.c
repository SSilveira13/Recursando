#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Envios.h"

/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int parser_EnviosFromText(FILE* pFile , LinkedList* this)
{
    int retorno = -1;
    Envios* aux;
    char var1[50],var3[50],var2[50],var4[50],var5[50],var6[50];
    if(pFile == NULL)
    {
        retorno = -1;
        //printf("Llega..."); system("pause");
    }
    else
    {
        fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^,],%[^\n]\n",var1,var2,var3,var4,var5,var6);
        do
        {
            retorno = fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^,],%[^\n]\n",var1,var2,var3,var4,var5,var6);
            //printf("%s %s %s %s", var1, var2, var3, var4);
            if(retorno==6)
            {
                aux = envio_nuevo();
                if(envio_parametros(aux,var1,var2,var3,var4,var5,var6)==0)
                {
                    ll_add(this,aux);
                    retorno = 0;
                }
            }
        }while(!feof(pFile));
    }
    fclose(pFile);
    return retorno;
}


