#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "parser.h"
#include "Envios.h"
#include "utn.h"

Envios* envio_nuevo()
{
    Envios *aux, *retorno=NULL;
    aux = (Envios*)malloc(sizeof(Envios));
    if(aux!=NULL)
    {
        retorno = aux;
    }
    return retorno;
}

int envio_parametros(Envios* pEnvio,char* var1,char* var2,char* var3,char* var4,char* var5,char* var6)
{
    int idEnvio,idCamion,kmRecorridos,tipoEntrega,retorno = -1;
    if(pEnvio!=NULL)
    {
        retorno = 0;
        idEnvio = atoi(var1);
        idCamion = atoi(var3);
        kmRecorridos = atoi(var5);
        tipoEntrega = atoi(var6);
        envio_setIdenvio(pEnvio,idEnvio);
        envio_setNombreProducto(pEnvio,var2);
        envio_setIdCamion(pEnvio,idCamion);
        envio_setZonaDestino(pEnvio,var4);
        envio_setKmRecorridos(pEnvio,kmRecorridos);
        envio_setTipoEntrega(pEnvio,tipoEntrega);
    }
    return retorno;
}

void envio_menu()
{
    printf("MENU\n1.Cargar Archivo\n2.Imprimir Envios\n3.Calcular Costos\n");
    printf("4.Generar Archivo De Costos Para Zona\n5.Imprimir Lista De Zonas\n6.Salir\n");
}



int envio_setIdenvio(Envios* this,int idEnvio)
{
    int retorno = -1;
    if(idEnvio >= 0 && this!=NULL)
    {
        this->id_envio = idEnvio;
        retorno = 0;
    }
    return retorno;
}
int envio_getIdenvio(Envios* this,int* idEnvio)
{
    int retorno = -1;
    if(this!=NULL)
    {
        retorno = 0;
        *idEnvio = this->id_envio;
    }
    return retorno;
}

int envio_setNombreProducto(Envios* this,char* nombre_producto)
{
    int retorno = -1;
    if(nombre_producto != NULL && this != NULL)
    {
        strcpy(this->nombre_producto,nombre_producto);
        retorno = 0;
    }
    return retorno;
}
int envio_getNombreProducto(Envios* this,char* nombre_producto)
{
    int retorno = -1;
    if(this!=NULL)
    {
        retorno = 0;
        strcpy(nombre_producto,this->nombre_producto);
    }
    return retorno;
}

int envio_setIdCamion(Envios* this,int idCamion)
{
    int retorno = -1;
    if(this != NULL)
    {
        this->id_camion = idCamion;
        retorno = 0;
    }
    return retorno;
}
int envio_getIdCamion(Envios* this,int* idCamion)
{
    int retorno = -1;
    if(this!=NULL)
    {
        retorno = 0;
        *idCamion = this->id_camion;
    }
    return retorno;
}

int envio_setZonaDestino(Envios* this,char* zonaDestino)
{
    int retorno = -1;
    if(zonaDestino >= 0 && this!=NULL)
    {
        strcpy(this->zona_destino,zonaDestino);
        retorno = 0;
    }
    return retorno;
}
int envio_getZonaDestino(Envios* this,char* zonaDestino)
{
    int retorno = -1;
    if(this!=NULL)
    {
        retorno = 0;
        strcpy(zonaDestino,this->zona_destino);
    }
    return retorno;
}


int envio_setKmRecorridos(Envios* this,int kmRecorridos)
{
    int retorno = -1;
    if(kmRecorridos >= 0 && this!=NULL)
    {
        this->km_recorridos = kmRecorridos;
        retorno = 0;
    }
    return retorno;
}
int envio_getKmRecorridos(Envios* this,int* kmRecorridos)
{
    int retorno = -1;
    if(this!=NULL)
    {
        retorno = 0;
        *kmRecorridos = this->km_recorridos;
    }
    return retorno;
}


int envio_setTipoEntrega(Envios* this,int TipoEntrega)
{
    int retorno = -1;
    if(TipoEntrega >= 0 && this!=NULL)
    {
        this->tipo_entrega = TipoEntrega;
        retorno = 0;
    }
    return retorno;
}
int envio_getTipoEntrega(Envios* this,int* TipoEntrega)
{
    int retorno = -1;
    if(this!=NULL)
    {
        retorno = 0;
        *TipoEntrega = this->tipo_entrega;
    }
    return retorno;
}



void envio_listar(LinkedList *this)
{
    if(this!=NULL)
    {
        int index,idEnvio,idCamion,kmRecorrido,tipoEntrega;
        char nombreProducto[50],zonaDestino[25];
        Envios* aux;
        for(index=0;index<=ll_len(this);index++)
        {
            aux = (Envios*)ll_get(this,index);
            envio_getIdenvio(aux,&idEnvio);
            envio_getNombreProducto(aux,nombreProducto);
            envio_getIdCamion(aux,&idCamion);
            envio_getZonaDestino(aux,zonaDestino);
            envio_getKmRecorridos(aux,&kmRecorrido);
            envio_getTipoEntrega(aux,&tipoEntrega);
            if(aux!=NULL)
            {
                printf("\nID de Envio: %d\tNombre de producto: %s\tID de Camion: %d\nZona de Destino: %s\tKilometros Recorridos: %d\nTipo de Entrega: %d\n\n",idEnvio,nombreProducto,idCamion,zonaDestino,kmRecorrido,tipoEntrega);
            }
        }
        system("pause");
    }
}

int envio_costos(int tipoEntrega,int kmRecorridos)
{
    int costo;
    if(kmRecorridos<=100)
    {
        costo = kmRecorridos * 50;
    }
    else
    {
        costo = kmRecorridos * 100;
    }
    if(tipoEntrega==0)
    {
        costo = costo + 250;
    }
    else if(tipoEntrega==1)
    {
        costo = costo + 420;
    }
    else if(tipoEntrega==2)
    {
        costo = costo + 75;
    }
    return costo;
}

LinkedList* listar_zonas(LinkedList* this)
{
    int index;
    int contador = 0;
    char zonaEnv[25];
    Envios *aux,*ficha;
    ficha = envio_nuevo();
    LinkedList* zonas;
    zonas = ll_newLinkedList();
    if(this!=NULL)
    {
        for(index=0;index<ll_len(this);index++)
        {
            aux = (Envios*)ll_get(this,index);
            envio_getZonaDestino(aux,zonaEnv);
            printf("\t%s\n",zonaEnv);
            envio_setZonaDestino(ficha,zonaEnv);
            //printf("%d\n",comprobar_zonas(zonas,zonaEnv));
            if(comprobar_zonas(zonas,zonaEnv)==0 || index==0)
            {
                contador++;
                ll_add(zonas,ficha);
                printf("%d.Destino: %s\n\n",contador,zonaEnv);
            }
        }
    }
    return zonas;
}

int comprobar_zonas(LinkedList* registradas,char* zona)
{
    int retorno = -1;
    int index;
    Envios* contenido;
    char aux[25];
    if(registradas!=NULL)
    {
        for(index=0;index<ll_len(registradas);index++)
        {
            contenido = (Envios*)ll_get(registradas,index);
            envio_getZonaDestino(contenido,aux);
            if(strcmp(zona,aux)==0)
            {
                retorno = 1;
                //break;
            }
            else
            {
                retorno = 0;
            }
        }
    }
    return retorno;
}


int envio_guardarTextoPorNivel(char* path , LinkedList* this)
{
    int retorno = -1;
    if(path!=NULL && this!=NULL)
    {
        FILE* bin;
        Envios* aux;
        int index,idEnvio,idCamion,kmRecorridos,tipoEntrega,costo=0;
        char nombreProducto[51],zonaDestino[25];
        if((bin=fopen(path,"w"))==NULL)
        {
            printf("El archivo no puede ser abierto");
        }
        else
        {
            retorno = 0;
            for(index=0;index<=ll_len(this);index++)
            {
                aux = (Envios*)ll_get(this,index);
                if(aux!=NULL)
                {
                    envio_getIdCamion(aux,&idCamion);
                    envio_getIdenvio(aux,&idEnvio);
                    envio_getKmRecorridos(aux,&kmRecorridos);
                    envio_getNombreProducto(aux,nombreProducto);
                    envio_getTipoEntrega(aux,&tipoEntrega);
                    envio_getZonaDestino(aux,zonaDestino);
                    costo = envio_costos(tipoEntrega,kmRecorridos);
                    fprintf(bin,"%d,%s,%d,%s,%d,%d,%d\n",idEnvio,nombreProducto,idCamion,zonaDestino,kmRecorridos,tipoEntrega,costo);
                }
            }
        }
        fclose(bin);
    }
    return retorno;
}
