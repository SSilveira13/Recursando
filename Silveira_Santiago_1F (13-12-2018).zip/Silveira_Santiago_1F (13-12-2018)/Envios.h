#ifndef ENVIOS_H_INCLUDED
#define ENVIOS_H_INCLUDED

struct Envios{
    int id_envio;
    char nombre_producto[50];
    int id_camion;
    char zona_destino[25];
    int km_recorridos;
    int tipo_entrega;
}typedef Envios;

Envios* envio_nuevo();

int envio_parametros(Envios* pEnvio,char* var1,char* var2,char* var3,char* var4,char* var5,char* var6);

void envio_menu();

int envio_setIdenvio(Envios* this,int idEnvio);
int envio_getIdenvio(Envios* this,int* idEnvio);
int envio_setNombreProducto(Envios* this,char* nombre_producto);
int envio_getNombreProducto(Envios* this,char* nombre_producto);
int envio_setIdCamion(Envios* this,int idCamion);
int envio_getIdCamion(Envios* this,int* idCamion);
int envio_setZonaDestino(Envios* this,char* zonaDestino);
int envio_getZonaDestino(Envios* this,char* zonaDestino);
int envio_setKmRecorridos(Envios* this,int kmRecorridos);
int envio_getKmRecorridos(Envios* this,int* kmRecorridos);
int envio_setTipoEntrega(Envios* this,int TipoEntrega);
int envio_getTipoEntrega(Envios* this,int* TipoEntrega);

void envio_listar(LinkedList *this);

int envio_costos(int tipoEntrega,int kmRecorridos);

LinkedList* listar_zonas(LinkedList* this);

int comprobar_zonas(LinkedList* registradas,char* zona);

int envio_guardarTextoPorNivel(char* path , LinkedList* this);

#endif
